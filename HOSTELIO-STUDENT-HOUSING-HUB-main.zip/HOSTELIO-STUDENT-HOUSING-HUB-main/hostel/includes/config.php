<?php
$dbuser="root";
$dbpass="hussain@123";
$host="localhost";
$db="hostel";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>